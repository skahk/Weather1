import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { ValidateGroupService } from './validate-group.service';
import { BackvalidService } from '../services/backvalid.service';
import { Http } from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-logingroup',
  templateUrl: './logingroup.component.html',
  styleUrls: ['./logingroup.component.css']
})
export class LogingroupComponent implements OnInit {

  logOrSign=true;
  signupclick=false;
  value=false;
  clicked=false;
  id="";
  
  validation = new ValidateGroupService(this.http);
  loginVerify= new BackvalidService(this.http);

  form = new FormGroup({
    'username':new FormControl('',[
      Validators.required,
      Validators.minLength(3),
      this.validation.cannotContainSpaces
    ]),
    'password'  :new FormControl('',[
      Validators.required,
      Validators.minLength(3),
      this.validation.cannotContainSpaces
    ])
  });

  formone = new FormGroup({
    'email':new FormControl('',[
      Validators.required,
      Validators.email
    ]),
    'ron'  :new FormControl('',[
      Validators.required,
      this.validation.formatcheck
    ]),
    'rtw'  :new FormControl('',[
      Validators.required,
      Validators.required,
      this.validation.formatcheck
    ]),
    'rth'  :new FormControl('',[
      Validators.required,
      Validators.required,
      this.validation.formatcheck
    ]),
    'tusername'  :new FormControl('',[
      Validators.required,
      Validators.minLength(3),
      this.validation.cannotContainSpaces,
    ]
  ),
    'tpassword'  :new FormControl('',[
      Validators.required,
      Validators.minLength(3),
      this.validation.cannotContainSpaces
    ]),
    'chpass'  :new FormControl('',[
      Validators.required,
      Validators.minLength(3),
      this.validation.cannotContainSpaces
    ])
  });

  constructor(private http:Http,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap
    .subscribe(params=>{
      this.id=params.get('id');
      this.validation.checkstud(this.id)
      .subscribe(res=>{
        this.value=res.json().verify;
        if(!(this.value))
        {
          this.router.navigate(['idNotCorrect']);
        }
      });;
    });
    
  }

  state(x)
  {
    if(x==0)
    {
      this.logOrSign=true;
      this.username.setValue("");
      this.username.markAsUntouched();
      this.password.markAsUntouched();
      this.password.setValue("");
    }
    else
    {
      this.logOrSign=false;
      this.tusername.setValue("");
      this.tusername.markAsUntouched();
      this.tpassword.setValue("");
      this.tpassword.markAsUntouched();
      this.email.setValue("");
      this.email.markAsUntouched();
      this.ron.setValue("");
      this.ron.markAsUntouched();
      this.rtw.setValue("");
      this.rtw.markAsUntouched();
      this.rth.setValue("");
      this.rth.markAsUntouched();
      this.chpass.setValue("");
      this.chpass.markAsUntouched();
    }
  }

  get username()
  {
    return this.form.get('username');
  }

  get password()
  {
    return this.form.get('password');
  }

  get email()
  {
    return this.formone.get('email');
  }

  get ron()
  {
    return this.formone.get('ron');
  }

  get rtw()
  {
    return this.formone.get('rtw');
  }

  get rth()
  {
    return this.formone.get('rth');
  }

  get tusername()
  {
    return this.formone.get('tusername');
  }

  get tpassword()
  {
    return this.formone.get('tpassword');
  }

  get chpass()
  {
    return this.formone.get('chpass');
  }

  signup()
  {
    this.signupclick=true;

    if(this.username.untouched||this.password.untouched||this.chpass.untouched||this.email.untouched||this.ron.untouched||this.rtw.untouched||this.rth.untouched)
    {
      if(this.tusername.untouched)
      {
        this.signupclick=false;
        this.tusername.markAsTouched();
        this.tusername.setValue('');
      }
      if(this.tpassword.untouched)
      {
        this.signupclick=false;
        this.tpassword.markAsTouched();
        this.tpassword.setValue('');
      }
      if(this.email.untouched)
      {
        this.signupclick=false;
        this.email.markAsTouched();
        this.email.setValue('');
      }
      if(this.ron.untouched)
      {
        this.signupclick=false;
        this.ron.markAsTouched();
        this.ron.setValue('');
      }
      if(this.rtw.untouched)
      {
        this.signupclick=false;
        this.rtw.markAsTouched();
        this.rtw.setValue('');
      }
      if(this.rth.untouched)
      {
        this.signupclick=false;
        this.rth.markAsTouched();
        this.rth.setValue('');
      }
      if(this.chpass.untouched)
      {
        this.signupclick=false;
        this.chpass.markAsTouched();
        this.chpass.setValue('');
      }
      if(this.tpassword.value!=this.chpass.value)
      {
        this.chpass.setErrors({"checkingIt":true});
        this.signupclick=false;
      }
      return;
    }

    if(this.formone.invalid)
    {
      this.signupclick=false;
      return;
    }
    else
    {
      this.loginVerify.postGroup(this.formone.value)
      .subscribe(res=>
        {
          if(res.json().id==null) 
          {
            this.signupclick=false;
            this.tusername.setErrors({alreadyTaken:true});
          }
          else
          {
            this.signupclick=false;
            console.log(res.json().id);
          }
        });
    }
  }

  loginSign()
  {
    this.clicked=true;
    if(this.username.untouched||this.password.untouched)
    {
      if(this.username.untouched)
      {
        this.username.markAsTouched();
        this.username.setValue('');
      }
      if(this.password.untouched)
      {
        this.password.markAsTouched();
        this.password.setValue('');
      }
      this.clicked=false;
      return;
    }
    if(this.form.invalid)
    {
      this.clicked=false;
      return;
    }
    else
    {
      this.loginVerify.verifyGroup(this.form.value)
      .subscribe(result=>{
        if(result.json().id==null)
        {
          this.clicked=false;
          this.form.setErrors({"loginfailed":true});
        }
        else
        {
          this.router.navigate(['preferences/'+result.json().id]);          
        }
      });      
    }
  }

}
