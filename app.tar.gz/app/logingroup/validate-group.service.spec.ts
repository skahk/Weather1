import { TestBed, inject } from '@angular/core/testing';

import { ValidateGroupService } from './validate-group.service';

describe('ValidateGroupService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ValidateGroupService]
    });
  });

  it('should be created', inject([ValidateGroupService], (service: ValidateGroupService) => {
    expect(service).toBeTruthy();
  }));
});
