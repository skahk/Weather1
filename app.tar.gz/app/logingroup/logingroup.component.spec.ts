import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogingroupComponent } from './logingroup.component';

describe('LogingroupComponent', () => {
  let component: LogingroupComponent;
  let fixture: ComponentFixture<LogingroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogingroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogingroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
