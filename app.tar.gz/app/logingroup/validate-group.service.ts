import { Injectable } from '@angular/core';
import { AbstractControl, ValidationErrors, FormGroup } from '@angular/forms';
import { Http } from '@angular/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ValidateGroupService {

  constructor(private http:Http) { }

  cannotContainSpaces(control:AbstractControl): ValidationErrors | null
    {
        if((control.value as string).indexOf(" ")>=0)
            return {cannotContainSpaces:true};

        return null;
    }

  formatcheck(control:AbstractControl): ValidationErrors | null
  {
    let xyz=(control.value as string).toLowerCase().split(".");
    if(xyz.length!=3)
      return {formatcheck:true};
    
    else
    {
      let re=xyz.pop();
      if(re.indexOf("u4cse")!=0||(re.length-10!=0)||xyz.pop().localeCompare("en")||xyz.pop().localeCompare("cb"))
        return {formatcheck:true};
    }
    
    return null;
  }

  shouldBeUnique(control:AbstractControl):Observable<ValidationErrors|null>
  {
      let a ={"name":control.value};
      this.http.post('https://projectallotamrita.herokuapp.com/saksham427742checkName',a)
    .subscribe(res=>{
      if(res.json().available==true)
        return {shouldBeUnique:true};
      else
        return null;
    });
    return null;
  }

    checkstud(x)
    {
      return this.http.post('https://projectallotamrita.herokuapp.com/saksham427742checkStudId',{"id":x});
    }

}
