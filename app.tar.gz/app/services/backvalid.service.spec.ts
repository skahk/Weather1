import { TestBed, inject } from '@angular/core/testing';

import { BackvalidService } from './backvalid.service';

describe('BackvalidService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BackvalidService]
    });
  });

  it('should be created', inject([BackvalidService], (service: BackvalidService) => {
    expect(service).toBeTruthy();
  }));
});
