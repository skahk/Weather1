import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class BackvalidService {

  constructor(private http:Http) { }

  getTeachers()
  {
    return this.http.get('https://projectallotamrita.herokuapp.com/getTeachers');
  }

  verifyGroup(x)
  {
    return this.http.post('https://projectallotamrita.herokuapp.com/saksham427742checkGroup',x);
  }

  postGroup(x)
  {
    return this.http.post('https://projectallotamrita.herokuapp.com/saksham427742createGroup',x);
  }
}
