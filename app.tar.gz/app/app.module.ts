import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { LogingroupComponent } from './logingroup/logingroup.component';
import { FrontComponent } from './front/front.component';
import { BackvalidService } from './services/backvalid.service';
import { ValidateGroupService } from './logingroup/validate-group.service';
import { ValidteacherService } from './teacher-login/validteacher.service';
import { TeacherLoginComponent } from './teacher-login/teacher-login.component';
import { PreferencesComponent } from './preferences/preferences.component';
import { PrefService } from './preferences/pref.service';
import { StudentLoginComponent } from './student-login/student-login.component';
import { NotFoundComponent } from './not-found/not-found.component';

@NgModule({
  declarations: [
    AppComponent,
    LogingroupComponent,
    FrontComponent,
    TeacherLoginComponent,
    PreferencesComponent,
    StudentLoginComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot([
      {path:'',component:FrontComponent},
      {path:'loggroup/:id',component:LogingroupComponent},
      {path:'preferences/:id',component:PreferencesComponent},
      {path:'logteacher',component:TeacherLoginComponent},
      {path:'logstudent',component:StudentLoginComponent},
      {path:'**',component:NotFoundComponent}
    ])
  ],
  providers: [
    BackvalidService,
    ValidateGroupService,
    ValidteacherService,
    PrefService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
