import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class StudbackService {

  constructor(private http:Http) { }

  confirm(x)
  {
    return this.http.post('https://projectallotamrita.herokuapp.com/saksham427742checkStudent',x);
  }
}
