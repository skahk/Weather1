import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { StudbackService } from './studback.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-student-login',
  templateUrl: './student-login.component.html',
  styleUrls: ['./student-login.component.css']
})
export class StudentLoginComponent implements OnInit {

  clicked=false;

  constructor(private http:Http,private router:Router) { }

  ngOnInit() {
  }

  form = new FormGroup({
    "username":new FormControl('',Validators.required),
    "password"  :new FormControl('',Validators.required)
  });

  get username()
  {
    return this.form.get('username');
  }

  get password()
  {
    return this.form.get('password');
  }

  signin()
  {
    this.clicked=true;
    if(this.username.untouched||this.password.untouched)
    {
      if(this.username.untouched)
      {
        this.username.markAsTouched();
        this.username.setValue("");
        this.clicked=false;
      }
      if(this.password.untouched)
      {
        this.password.markAsTouched();
        this.password.setValue("");
        this.clicked=false;
      }
      return;
    }
    else if(this.username.invalid||this.password.invalid)
    {
      this.clicked=false;
      return;
    }
    let back = new StudbackService(this.http);
    back.confirm(this.form.value)
    .subscribe(res=>{
      if(res.json().id==null)
      {
        this.form.setErrors({invalid:true});
        this.clicked=false;
      }
      else
      {
        this.router.navigate(['loggroup/'+res.json().id]);
      }
    });
  }

}
