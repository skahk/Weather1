import { TestBed, inject } from '@angular/core/testing';

import { StudbackService } from './studback.service';

describe('StudbackService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StudbackService]
    });
  });

  it('should be created', inject([StudbackService], (service: StudbackService) => {
    expect(service).toBeTruthy();
  }));
});
