import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { ValidteacherService } from './validteacher.service';

@Component({
  selector: 'app-teacher-login',
  templateUrl: './teacher-login.component.html',
  styleUrls: ['./teacher-login.component.css']
})
export class TeacherLoginComponent implements OnInit {

  validation = new ValidteacherService(this.http);

  constructor(private http : Http) { }

  ngOnInit() {
  }

  form = new FormGroup({
    "username":new FormControl('',[
      Validators.required
    ]),
    "password"  :new FormControl('',[
      Validators.required
    ])
  });

  get username()
  {
    return this.form.get('username');
  }

  get password()
  {
    return this.form.get('password');
  }

  signin()
  {
    this.validation.validateTeacher(this.form.value)
    .subscribe(res=>{
      
      if(res)
      console.log("Credentials are correct")
      else
      this.form.setErrors({invalidValues:true});
    });
  }

}
