import { TestBed, inject } from '@angular/core/testing';

import { ValidteacherService } from './validteacher.service';

describe('ValidteacherService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ValidteacherService]
    });
  });

  it('should be created', inject([ValidteacherService], (service: ValidteacherService) => {
    expect(service).toBeTruthy();
  }));
});
