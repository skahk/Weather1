import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { BackvalidService } from '../services/backvalid.service';
import { FormGroup, FormControl, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { PrefService } from './pref.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-preferences',
  templateUrl: './preferences.component.html',
  styleUrls: ['./preferences.component.css']
})
export class PreferencesComponent implements OnInit {

  clicked=false;
  isOpen=false;
  indexOne=0;
  indexTwo=0;
  indexThree=0;
  postObject={id:"",prefOne:"",prefTwo:"",prefThree:"",areasOfInterest:""};
  teachers : any[];
  numTeachers=0;
  getter = new BackvalidService(this.http);
  defaultValue="select-teacher";
  ser=new PrefService(this.http);
  check=false;

  constructor(private http: Http,private route: ActivatedRoute,private router:Router) { }

  ngOnInit() {
    this.route.paramMap
    .subscribe(params=>{
      this.postObject.id=params.get('id');
      this.ser.verify(this.postObject.id)
      .subscribe(res=>{
        this.check=res.json().verify;
        if(!this.check)
        {
          this.router.navigate(['idNotCorrect']);
        }
      });
    });
    this.getter.getTeachers().subscribe(res=>{
      this.teachers=res.json();
      this.numTeachers=this.teachers.length;
    });
  }

  form = new FormGroup({
    'prefOne':new FormControl('',this.ser.cannotBeNull),
    'prefTwo'  :new FormControl('',this.ser.cannotBeNull),
    'prefThree'  :new FormControl('',this.ser.cannotBeNull),
    'areasOfInterest' :new FormControl('',Validators.required)
  });
  
  log()
  {
    console.log("hii");
  }

  get areasOfInterest()
  {
    return this.form.get('areasOfInterest');
  }

  get prefOne()
  {
    return this.form.get('prefOne');
  }

  get prefTwo()
  {
    return this.form.get('prefTwo');
  }

  get prefThree()
  {
    return this.form.get('prefThree');
  }

  pref()
  {
    console.log(this.prefOne.value);
    return true;
  }

  subform()
  {
    this.clicked=true;
    if(this.prefOne.untouched||this.prefTwo.untouched||this.prefThree.untouched||this.areasOfInterest.untouched)
    {
      this.clicked=false;

      if(this.prefOne.untouched)
      {
        this.prefOne.markAsTouched();
        this.prefOne.setErrors({'cannotBeNull' : true});
      }

      if(this.prefTwo.untouched)
      {
        this.prefTwo.markAsTouched();
        this.prefTwo.setErrors({'cannotBeNull' : true});
      }

      if(this.prefThree.untouched)
      {
        this.prefThree.markAsTouched();
        this.prefThree.setErrors({'cannotBeNull' : true});
      }
      
      if(this.areasOfInterest.untouched)
      {
        this.areasOfInterest.markAsTouched();
        this.areasOfInterest.setValue('');
      }

      return;
    }
    this.prefOne.setErrors(null);
    this.prefTwo.setErrors(null);
    this.prefThree.setErrors(null);
    if((this.prefOne.value).localeCompare(this.prefTwo.value)==0 &&(this.prefThree.value).localeCompare(this.prefTwo.value)==0)
    {
      this.clicked=false;
      this.prefOne.setErrors({oneTwoThree:true});
      this.prefTwo.setErrors({oneTwoThree:true});
      this.prefThree.setErrors({oneTwoThree:true});
    }
    else if((this.prefOne.value).localeCompare(this.prefTwo.value)==0)
    {
      this.clicked=false;
      this.prefOne.setErrors({oneTwo:true});
      this.prefTwo.setErrors({oneTwo:true});
    }
    else if((this.prefOne.value).localeCompare(this.prefThree.value)==0)
    {
      this.clicked=false;
      this.prefOne.setErrors({oneThree:true});
      this.prefThree.setErrors({oneThree:true});
    }
    else if((this.prefTwo.value).localeCompare(this.prefThree.value)==0)
    {
      this.clicked=false;
      this.prefTwo.setErrors({twoThree:true});
      this.prefThree.setErrors({twoThree:true});
    }

    else
    {
      this.postObject.prefOne=this.prefOne.value;
      this.postObject.prefTwo=this.prefTwo.value;
      this.postObject.prefThree=this.prefThree.value;
      this.postObject.areasOfInterest=this.areasOfInterest.value;
      this.ser.updatePreferences(this.postObject).subscribe(res=>{
        this.clicked=false;
        console.log(res.json());
      });
    }
  }
}
