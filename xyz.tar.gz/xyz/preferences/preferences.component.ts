import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { BackvalidService } from '../services/backvalid.service';
import { FormGroup, FormControl, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { PrefService } from './pref.service';

@Component({
  selector: 'app-preferences',
  templateUrl: './preferences.component.html',
  styleUrls: ['./preferences.component.css']
})
export class PreferencesComponent implements OnInit {

  isOpen=false;
  indexOne=0;
  indexTwo=0;
  indexThree=0;
  postObject={prefOne:String,prefTwo:String,prefThree:String,areasOfInterest:String};
  teachers : any[];
  numTeachers=0;
  getter = new BackvalidService(this.http);
  defaultValue="select-teacher";
  ser=new PrefService(this.http);

  constructor(private http: Http) { }

  ngOnInit() {
    this.getter.getTeachers().subscribe(res=>{
      this.teachers=res.json();
      this.numTeachers=this.teachers.length;
    });
  }

  form = new FormGroup({
    'prefOne':new FormControl('',this.ser.cannotBeNull),
    'prefTwo'  :new FormControl('',[this.ser.cannotBeNull]),
    'prefThree'  :new FormControl('',this.ser.cannotBeNull),
    'areasOfInterest' :new FormControl('',Validators.required)
  });
  
  log()
  {
    console.log("hii");
  }

  get areasOfInterest()
  {
    return this.form.get('areasOfInterest');
  }

  get prefOne()
  {
    return this.form.get('prefOne');
  }

  get prefTwo()
  {
    return this.form.get('prefTwo');
  }

  get prefThree()
  {
    return this.form.get('prefThree');
  }

  pref()
  {
    console.log(this.prefOne.value);
    return true;
  }

  subform()
  {
    if(this.prefOne.untouched||this.prefTwo.untouched||this.prefThree.untouched||this.form.errors)
    {
      this.prefOne.markAsTouched;
      this.prefOne.updateValueAndValidity;
      this.prefTwo.markAsTouched;
      this.prefTwo.updateValueAndValidity;
      this.prefThree.markAsTouched;
      this.prefTwo.updateValueAndValidity;
      return;
    }
    console.log("called");
    this.prefOne.setErrors(null);
    this.prefTwo.setErrors(null);
    this.prefThree.setErrors(null);
    if((this.prefOne.value).localeCompare(this.prefTwo.value)==0 &&(this.prefThree.value).localeCompare(this.prefTwo.value)==0)
    {
      this.prefOne.setErrors({oneTwoThree:true});
      this.prefTwo.setErrors({oneTwoThree:true});
      this.prefThree.setErrors({oneTwoThree:true});
    }
    else if((this.prefOne.value).localeCompare(this.prefTwo.value)==0)
    {
      this.prefOne.setErrors({oneTwo:true});
      this.prefTwo.setErrors({oneTwo:true});
    }
    else if((this.prefOne.value).localeCompare(this.prefThree.value)==0)
    {
      this.prefOne.setErrors({oneThree:true});
      this.prefThree.setErrors({oneThree:true});
    }
    else if((this.prefTwo.value).localeCompare(this.prefThree.value)==0)
    {
      this.prefTwo.setErrors({twoThree:true});
      this.prefThree.setErrors({twoThree:true});
    }

    else
    {
      this.postObject.prefOne=this.prefOne.value;
      this.postObject.prefTwo=this.prefTwo.value;
      this.postObject.prefThree=this.prefThree.value;
      this.postObject.areasOfInterest=this.areasOfInterest.value;
      console.log(this.postObject);
    }
  }
}
