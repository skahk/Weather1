import { Injectable } from '@angular/core';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import { Http } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class PrefService {

  constructor(private http:Http) { }

  cannotBeNull(control:AbstractControl): ValidationErrors | null
    {
        if( (control.value as String).localeCompare("")==0 || (control.value as String).localeCompare("select-teacher")==0 )
            return {cannotBeNull:true};
        return null;
    }


    updatePreferences(x)
    {
        this.http.post('https://projectallotamrita.herokuapp.com/saksham427742updateGroup',x);
    }

}
