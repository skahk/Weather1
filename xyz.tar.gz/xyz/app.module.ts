import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { LogingroupComponent } from './logingroup/logingroup.component';
import { FrontComponent } from './front/front.component';
import { BackvalidService } from './services/backvalid.service';
import { ValidateGroupService } from './logingroup/validate-group.service';
import { ValidteacherService } from './teacher-login/validteacher.service';
import { TeacherLoginComponent } from './teacher-login/teacher-login.component';
import { PreferencesComponent } from './preferences/preferences.component';
import { PrefService } from './preferences/pref.service';

@NgModule({
  declarations: [
    AppComponent,
    LogingroupComponent,
    FrontComponent,
    TeacherLoginComponent,
    PreferencesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot([
      {path:'',component:LogingroupComponent},
      {path:'logstudent',component:LogingroupComponent},
      {path:'preferences',component:PreferencesComponent},
      {path:'logteacher',component:TeacherLoginComponent}
    ])
  ],
  providers: [
    BackvalidService,
    ValidateGroupService,
    ValidteacherService,
    PrefService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
