import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class ValidteacherService {

  constructor(private http:Http) { }

  validateTeacher(x)
  {
    return this.http.post('https://projectallotamrita.herokuapp.com/saksham427742checkTeacher',x);
  }

}
