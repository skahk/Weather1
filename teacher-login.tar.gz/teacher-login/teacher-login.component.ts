import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { ValidteacherService } from './validteacher.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-teacher-login',
  templateUrl: './teacher-login.component.html',
  styleUrls: ['./teacher-login.component.css']
})
export class TeacherLoginComponent implements OnInit {

  validation = new ValidteacherService(this.http);

  clicked=false;

  constructor(private http : Http,private router:Router) { }

  ngOnInit() {
  }

  form = new FormGroup({
    "username":new FormControl('',[
      Validators.required
    ]),
    "password"  :new FormControl('',[
      Validators.required
    ])
  });

  get username()
  {
    return this.form.get('username');
  }

  get password()
  {
    return this.form.get('password');
  }

  signin()
  {
    this.clicked=true;
    if(this.username.untouched||this.password.untouched)
    {
      if(this.username.untouched)
      {
        this.username.markAsTouched();
        this.username.setValue("");
        this.clicked=false;
      }
      if(this.password.untouched)
      {
        this.password.markAsTouched();
        this.password.setValue("");
        this.clicked=false;
      }
      return;
    }
    else if(this.username.invalid||this.password.invalid)
    {
      this.clicked=false;
      return;
    }
    this.validation.validateTeacher(this.form.value)
    .subscribe(res=>{
      this.clicked=false;
      if(res.json().verify)
        this.router.navigate(['underconstruct']);
      else
      {
        this.form.setErrors({invalidValues:true});
        console.log("incorrect credentials");
      }
    });
  }

}
