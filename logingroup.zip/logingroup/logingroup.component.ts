import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { ValidateGroupService } from './validate-group.service';
import { BackvalidService } from '../services/backvalid.service';
import { Http } from '@angular/http';

@Component({
  selector: 'app-logingroup',
  templateUrl: './logingroup.component.html',
  styleUrls: ['./logingroup.component.css']
})
export class LogingroupComponent implements OnInit {

  logOrSign=true;
  validation = new ValidateGroupService(this.http);
  loginVerify= new BackvalidService(this.http);

  form = new FormGroup({
    'username':new FormControl('',[
      Validators.required,
      Validators.minLength(3),
      this.validation.cannotContainSpaces
    ]),
    'password'  :new FormControl('',[
      Validators.required,
      Validators.minLength(3),
      this.validation.cannotContainSpaces
    ])
  });

  formone = new FormGroup({
    'email':new FormControl('',[
      Validators.required,
      Validators.email
    ]),
    'ron'  :new FormControl('',[
      Validators.required,
      this.validation.formatcheck
    ]),
    'rtw'  :new FormControl('',[
      Validators.required,
      Validators.required,
      this.validation.formatcheck
    ]),
    'rth'  :new FormControl('',[
      Validators.required,
      Validators.required,
      this.validation.formatcheck
    ]),
    'tusername'  :new FormControl('',[
      Validators.required,
      Validators.minLength(3),
      this.validation.cannotContainSpaces,
    ]
  ),
    'tpassword'  :new FormControl('',[
      Validators.required,
      Validators.minLength(3),
      this.validation.cannotContainSpaces
    ]),
    'chpass'  :new FormControl('',[
      Validators.required,
      Validators.minLength(3),
      this.validation.cannotContainSpaces
    ])
  });

  constructor(private http:Http) {   }

  ngOnInit() {
  }

  validate()
  {
    if(this.tpassword.value!=this.chpass.value)
      this.chpass.setErrors({"checkingIt":true});
  }

  state(x)
  {
    if(x==0)
    {
      this.logOrSign=true;
      this.username.setValue("");
      this.username.markAsUntouched();
      this.password.markAsUntouched();
      this.password.setValue("");
    }
    else
    {
      this.logOrSign=false;
      this.tusername.setValue("");
      this.tusername.markAsUntouched();
      this.tpassword.setValue("");
      this.tpassword.markAsUntouched();
      this.email.setValue("");
      this.email.markAsUntouched();
      this.ron.setValue("");
      this.ron.markAsUntouched();
      this.rtw.setValue("");
      this.rtw.markAsUntouched();
      this.rth.setValue("");
      this.rth.markAsUntouched();
      this.chpass.setValue("");
      this.chpass.markAsUntouched();
    }
  }

  get username()
  {
    return this.form.get('username');
  }

  get password()
  {
    return this.form.get('password');
  }

  get email()
  {
    return this.formone.get('email');
  }

  get ron()
  {
    return this.formone.get('ron');
  }

  get rtw()
  {
    return this.formone.get('rtw');
  }

  get rth()
  {
    return this.formone.get('rth');
  }

  get tusername()
  {
    return this.formone.get('tusername');
  }

  get tpassword()
  {
    return this.formone.get('tpassword');
  }

  get chpass()
  {
    return this.formone.get('chpass');
  }

  signup()
  {
    this.validate();
    if(this.formone.errors!=null||this.tusername.untouched||this.tpassword.untouched)
    {
      this.formone.setErrors({"signupfailed":true});
    }
    else
    {
      this.loginVerify.postGroup(this.formone.value)
      .subscribe(res=>
        {
          console.log(res);
          if(res.json().tusername==null)
          {
            this.tusername.setErrors({alreadyTaken:true});
          }
        });
    }
  }

  loginSign()
  {
    if(this.form.errors!=null||this.username.untouched||this.password.untouched)
    {
      console.log('Errors are there...');
      this.form.setErrors({"loginfailed":true});
    }
    else
    {
      this.loginVerify.verifyGroup(this.form.value)
      .subscribe(result=>{
        if(result.json().length>0)
        {
          console.log("Credentials are correct");
        }
        else
        {
          this.form.setErrors({"loginfailed":true});
        }
      });      
    }
  }

}
